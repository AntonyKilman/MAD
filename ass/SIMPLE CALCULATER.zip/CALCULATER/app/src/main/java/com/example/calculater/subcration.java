package com.example.calculater;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class subcration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcration);
    }
}