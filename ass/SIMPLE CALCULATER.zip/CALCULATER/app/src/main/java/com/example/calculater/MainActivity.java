package com.example.calculater;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Intent intent;
    Button addition,subraction,multiplication,divition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addition=(Button)findViewById(R.id.addition);
        subraction=(Button)findViewById(R.id.subraction);
        multiplication=(Button)findViewById(R.id.multiplication);
        divition=(Button)findViewById(R.id.divition);
    }
    public void addition(View view) {
        if(view.getId()==R.id.addition){
            Toast.makeText(this, "YOU SELECTED ADDITION", Toast.LENGTH_LONG).show();
        }
    }
    public void subraction(View view) {
        intent = new Intent(this,subcration.class);
        if(view.getId()==R.id.subraction){
            Toast.makeText(this, "YOU SELECTED SUBTRATION", Toast.LENGTH_LONG).show();
            startActivity(intent);
        }
    }
    public void multiplication(View view) {
        if(view.getId()==R.id.multiplication){
            Toast.makeText(this, "YOU SELECTED MULTIPILICATION", Toast.LENGTH_LONG).show();
        }
    }
    public void divition(View view) {
        if(view.getId()==R.id.divition){
            Toast.makeText(this, "YOU SELECTED DIVISION", Toast.LENGTH_LONG).show();
        }
    }
}